<?php

namespace App\Database\MySQLi;

use CodeIgniter\Database\MySQLi\Builder as BaseBuilder;

/**
* Builder for MySQLi
*/
class Builder extends BaseBuilder
{

} 