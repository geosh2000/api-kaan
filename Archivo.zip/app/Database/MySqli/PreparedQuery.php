<?php

namespace App\Database\MySQLi;

use CodeIgniter\Database\MySQLi\PreparedQuery as BasePreparedQuery;

/**
* PreparedQuery for MySQLi
*/
class PreparedQuery extends BasePreparedQuery
{

} 