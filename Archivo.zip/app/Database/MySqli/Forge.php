<?php

namespace App\Database\MySQLi;

use CodeIgniter\Database\MySQLi\Forge as BaseForge;

/**
* Forge for MySQLi
*/
class Forge extends BaseForge
{

} 