<?php

namespace App\Database\MySQLi;

use CodeIgniter\Database\MySQLi\Utils as BaseUtils;

/**
* Utils for MySQLi
*/
class Utils extends BaseUtils
{

} 