<?php

namespace App\Database\MySQLi;

use CodeIgniter\Database\MySQLi\Result as BaseResult;

/**
* Result for MySQLi
*/
class Result extends BaseResult
{

} 