<?= $this->extend('Layouts/Zendesk/main') ?>

<?= $this->section('content') ?>
    <div class="container">
        <div class="d-flex justify-content-between" id="rsvLine">
            <div>
                <p>Huesped: <span id="$huesped"></span></p>
                <p>Reserva: <span id="$rsva"></span></p>
            </div>
            <button class="btn btn-primary searchExistent">
                <i class="fas fa-search"></i>
            </button>
        </div>
        <hr>
        <div id="result"></div>
    </div>

    <!-- HISTORY MODAL -->
    <div class="modal fade" data-backdrop="static" id="historyModal" tabindex="-1" role="dialog" aria-labelledby="historyModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="historyModalLabel">Historial de Transporte</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <table class="table table-striped" id="historyTable">
                        <!-- Los datos se cargarán aquí -->
                    </table>
                </div>
            </div>
        </div>
    </div>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script>
    class Transfers {
        constructor(client, globals) {
            this.client = client;
            this.globals = globals;
            this.getFields = [
                "ticket",
                "currentUser",
                'ticket.customField:custom_field_26495291237524', // Categoria
                'ticket.customField:custom_field_26260741418644', // Reserva
            ];
            this.user = {};
        }

        reload() {
            // Obtiene la información del ticket
            this.client.get(this.getFields)
                .then((data) => {
                    const ticketData = {
                        ticket: data.ticket,
                        categoria: data['ticket.customField:custom_field_26495291237524'],
                        reserva: {
                            class: (!data['ticket.customField:custom_field_26260741418644'] || data['ticket.customField:custom_field_26260741418644'].trim() === '') ? 'text-danger' : '',
                            error: (!data['ticket.customField:custom_field_26260741418644'] || data['ticket.customField:custom_field_26260741418644'].trim() === '') ? true : false,
                            errorMsg: '<b>Registrar Reserva en Formulario</b>',
                            id: data['ticket.customField:custom_field_26260741418644']?.trim(),
                        }
                    };
                    this.user = data.currentUser;
                    this.buildBody(ticketData);
                })
                .catch((error) => {
                    console.error('Error obteniendo el ID del ticket:', error);
                    document.body.innerHTML = `<h1>Error obteniendo el ID del ticket</h1>`;
                });
        }

        buildBody(data) {
            const mainDiv = document.getElementById('main');
            const appTitle = document.getElementById('appTitle');

            appTitle.innerHTML = "Transportaciones";

            // Muestra la información en el cuerpo del documento
            mainDiv.innerHTML = `
                <div class='d-flex justify-content-between align-items-center'>
                    <p class="${ data.reserva.class }">Reserva PMS: ${ data.reserva.error ? data.reserva.errorMsg : data.reserva.id }</p>
                    ${ data.reserva.error ? '' : "<button id='searchPMS' class='btn btn-primary' style='zoom:0.8'><i class='fas fa-search'></i></button>" }
                </div>
                <p>Categoria: ${data.categoria}</p>
                <p>Requester: ${data.ticket.requester.name}</p>
                <p>E-mail: ${data.ticket.requester.email}</p>
                <p>Formulario: ${data.ticket.form.id}</p>
                <p>Idioma: ${data.ticket.requester.locale}</p>
            `;

            // Añade el listener de eventos al botón searchPMS si existe
            const searchPMSButton = document.getElementById('searchPMS');
            if (searchPMSButton) {
                searchPMSButton.addEventListener('click', () => {
                    this.searchFolio(data.reserva.id);
                });
            }
        }

        searchFolio( folio ){
            // Codificar username:token en base64
            // const encodedToken = btoa(this.user.email + ":{{setting.apiToken}}");

            const options = {
                url: 'https://api.geoshglobal.com/adh/index.php/zdapp/transpo/searchFolio/' + folio,
                type: 'GET',
                headers: {
                    Authorization: "Basic {{setting.apiToken}}",
                },
                accepts: "application/json",
                secure: true,            
                cors: false
            };
            console.log(options.url);
            
            this.client.request(options).then(
                (data) => {
                    console.log(data,options.url);
                },
                (error) => {
                    console.log(error,options.url);
                    alert('Hubo un error al cargar los datos.');
                }
            );
            
        }
    }

    $(document).ready(function () {
        console.log("Index grupo de funciones ready");

        const appTitle = document.getElementById('appTitle');
        appTitle.innerHTML = "GG - ADH Transfers";

        var getFields = [
            "ticket",
            "currentUser",
            'ticket.customField:custom_field_26495291237524', // Categoria
            'ticket.customField:custom_field_26260741418644', // Reserva
            'ticket.customField:custom_field_26260771754900', // Guest
        ];
        
        var zafData = {};

        $(document).on('click', '.reloadBtn', function(){
            buildData();
        });
        
        // ZAF METHODS
        var client = ZAFClient.init();
        buildData();

        function buildData(  ){
            client.get(getFields).then(function(data) {
                console.log(data);
                zafData = data;
                setUser(data.currentUser.name);
                printRsva(data['ticket.customField:custom_field_26260741418644']);
                printGuest(data['ticket.customField:custom_field_26260771754900']);
            });
        }

        function setUser( user ){
            const userDiv = document.getElementById('$user');
            userDiv.innerHTML = user;
        }

        function printRsva( rsva ){
            const rsvaId = document.getElementById('$rsva');
            rsvaId.innerHTML = rsva;
        }

        function printGuest( guest ){
            const rsvaId = document.getElementById('$huesped');
            rsvaId.innerHTML = guest;
        }

        $(document).on('click', '.searchExistent', function(){
            var getFields = [
                'ticket.customField:custom_field_26260741418644',   // Rsva
                'ticket.customField:custom_field_26260771754900'    // Guest
            ];
            client.get(getFields).then(function(data){
                var id = data['ticket.customField:custom_field_26260741418644']?.trim();
                var name = data['ticket.customField:custom_field_26260771754900']?.trim();
                printRsva( id );
                printGuest( name );

                if( (id != null && id != "") || (name != null && name != "") ){
                    searchResult( id, name );
                }else{
                    var result = document.getElementById('result');
                    var msg = "Debes introducir la reserva o el nombre del huésped en el campo del formulario";
                    $('#rsvLine').hide();
                    result.innerHTML = `<div class="rsvError d-flex alert alert-danger"><span>${ msg }</span><button class="ml-auto btn btn-secondary searchExistent"><i class="fas fa-sync-alt"></i></button></div>`;
                }
            });
        });

        function searchCrs( id, name ){
   
            $('#rsvLine').show();
            var searchF = (id != null && id != "") ? id : name;
            var url = '<?= site_url('/zdappC/transpo/getRsvHtml/') ?>' + searchF;
            startLoader();
    
            $.ajax({
                url: url,
                method: 'GET',
                success: function(data) {
                    startLoader(false);
                    // console.log(data);
                    
                    var result = document.getElementById('result');
                    result.innerHTML = data;

                    // Delegación de eventos
                    document.getElementById('result').addEventListener('click', function(event) {
                        var target = event.target;

                        // Verifica si el elemento clicado es un botón con el atributo 'data-ticket-id'
                        if (target.matches('button[data-reg]')) {
                            var pmsId = target.getAttribute('data-reg');
                            var selectedData = JSON.parse(document.getElementById('json-'+pmsId).value);
                            console.log(selectedData);
                        }
                    });
                },
                error: function() {
                    var result = document.getElementById('result');
                    var msg = "Error al cargar resultados. Vuelve a intentar";
                    result.innerHTML = `<div class="rsvError d-flex alert alert-danger"><span>${ msg }</span><button class="ml-auto btn btn-secondary searchExistent"><i class="fas fa-sync-alt"></i></button></div>`;
                    startLoader(false);
                    return true;
                }
            });
        }

        function searchResult( id, name ){

            $('#rsvLine').show();
            var searchF = (id != null && id != "") ? id : name;
            var url = '<?= site_url('zdappC/transpo/searchFolio/') ?>' + searchF;
            startLoader();

            $.ajax({
                url: url,
                method: 'GET',
                success: function(data) {
                    startLoader(false);

                    var result = document.getElementById('result');
                    // if( data.data.length > 0 ){
                    //     // result.innerHTML = '<pre>' + JSON.stringify(data) + "</pre>";
                    //     buildTable(data.data);
                    // }else{
                    //     searchCrs( id, name );
                    //     // displayNewForm();
                    // }
                    console.log(data.trim());
                    if( data.trim() == 'empty' ){
                        searchCrs( id, name );
                    }else{
                        var searchButton = `<div class="mb-2 d-flex justify-content-end"><button class="btn btn-primary" id="extendedSearch">Extender a CRS</button></div>`;
                        result.innerHTML = searchButton + data;

                        // Delegación de eventos
                        document.getElementById('extendedSearch').addEventListener('click', function(event) {
                            searchCrs(id, name);
                        });
                    }
                },
                error: function() {
                    alert('Hubo un error al cargar los datos.');
                    startLoader(false);
                }
            });
        }

        function buildTable( data ){
            $('#result').html = '';

            setHotel( data[0].hotel );
            setGuest( data[0].guest );

            var cardHeader = `<div class="card-header" style="line-height:0.5">
                            <h5 class="card-title">${data[0].guest}</h5>
                            <p class="card-text"><small class="text-muted">Mail: ${data[0].correo} / Tel: ${data[0].phone}</small></p>
                            <p class="card-text"><small class="text-muted">${data[0].hotel} ( ${data[0].isIncluida == "0" ? "Con Costo" : "Incluida"} ) / ${data[0].folio} - ${data[0].pax} pax</small></p>
                        </div>`;
                
            var htmlLine = "";

            // Iterar sobre los elementos del arreglo y construir el HTML
            data.forEach(function(item) {
                var ticketsArray = [];
                try {
                    ticketsArray = Object.values(JSON.parse(item.tickets));
                } catch (e) {
                    console.error("Error parsing tickets:", e);
                }

                var ticketsString = "";
                ticketsArray.forEach( function(item) {
                    ticketsString = `${ticketsString}<button type="button" data-ticket-id="${item}" class="btn btn-link" style="zoom: 0.7">${item}</button> `;
                });


                htmlLine = `${htmlLine}
                    <h5> ${item.tipo} [${item.item}]</h5>
                    <p class="card-text"><strong>Fecha:</strong> ${item.date} (${item.time})</p>
                    <p class="card-text"><strong>Vuelo:</strong> ${item.airline} (${item.flight})</p>
                    <p class="card-text"><strong>Status:</strong> ${item.status}</p>
                    <p class="card-text"><strong>Tickets:</strong> ${ ticketsString } </p>
                    <hr>
                `;
            });

            var html = `
                <div class="card mb-3">
                    ${cardHeader}
                    <div class="card-body" style="line-height:0.5">
                        ${ htmlLine }
                    </div>
                </div>
            `;
            $('#result').html(html);

            // Delegación de eventos
            document.getElementById('result').addEventListener('click', function(event) {
                var target = event.target;

                // Verifica si el elemento clicado es un botón con el atributo 'data-ticket-id'
                if (target.matches('button[data-ticket-id]')) {
                    var ticketId = target.getAttribute('data-ticket-id');
                    openTicket(ticketId);
                }
            });
        }

        function openTicket( tkt ){
            client.invoke('routeTo', 'ticket', tkt)
                .then(function() {

                })
                .catch(function(error) {
                    console.error('Error al navegar al ticket:', error);
                });
        }

        function setHotel( hotel ){
            var mapHotel = {
                "atelier": "atpm",
                "atelier playa mujeres": "atpm",
                "atpm": "atpm",
                "oleo": "olcp",
                "oleo cancun playa": "olcp",
                "olcp": "olcp",
            };
            var htl = 'hotel_' + mapHotel[hotel.toLowerCase()];
            console.log('set hotel to ' + htl );
            client.set('ticket.customField:custom_field_26493544435220', htl).then(function(data) {
                console.log("Hotel establecido como " + htl, data);
            });
        }

        function setGuest( guest ){
            console.log('set huesped to ' + guest );
            client.set('ticket.customField:custom_field_26260771754900', guest).then(function(data) {
                console.log("Hotel establecido como " + guest, data);
            });
        }

        function setTravelType( v ){
            console.log('set Transpo Pago to ' + v );
            client.set('ticket.customField:custom_field_28630449017748', v).then(function(data) {
                console.log("Tipo de Transpo como " + v, data);
            });
        }

        function setTranspoPago( pago ){
            console.log('set Transpo Pago to ' + pago );
            client.set('ticket.customField:custom_field_28630467255444', pago).then(function(data) {
                console.log("Transpo Pago como " + pago, data);
            });
        }

        function setField( f, v, n ){
            client.set(f, v).then(function(data) {
                console.log(n + " como " + v, data);
            });
        }

        function setLang( id, lang ){
            client.request({
                url: `/api/v2/users/${id}.json`,
                type: 'PUT',
                data: JSON.stringify({
                    user: {
                        locale: lang
                    }
                }),
                contentType: 'application/json',
                dataType: 'json'
            }).then(function(response) {
                console.log('Idioma actualizado a ' + lang + ':', response);
            }).catch(function(error) {
                console.error('Error al actualizar el idioma:', error);
            });
        }
        

        function displayNewForm(){

            var getF = [
                'ticket',
                'ticket.customField:custom_field_26493544435220', // hotel
                'ticket.customField:custom_field_26260771754900', // huesped
                'ticket.customField:custom_field_28630467255444', // transpo_pago
                'ticket.customField:custom_field_28630449017748' // tipo
            ];
            client.get(getF).then(function(data){

                console.log(data);

                var zd = {
                    hotel: data['ticket.customField:custom_field_26493544435220'],
                    huesped: data['ticket.customField:custom_field_26260771754900'],
                    pago: data['ticket.customField:custom_field_28630467255444'],
                    travel: data['ticket.customField:custom_field_28630449017748'],
                    lang: data.ticket.requester.locale,
                    requesterId: data.ticket.requester.id,
                };

                var form = $('<form class="form-inline" id="newRegForm"></form>');
    
                // Input for Guest Name
                var guestNameInput = $('<input>', {
                    type: 'text',
                    name: 'guestName',
                    placeholder: 'Guest Name',
                    class: 'form-control mb-2 mr-sm-2',
                    value: zd.huesped
                });
    
                // Input for Guest Name
                var guestLang = $('<select>', {
                    name: 'idioma',
                    class: 'form-control mb-2 mr-sm-2'
                });

                var optionl1 = $('<option>', {
                    text: 'Ingles (Estados Unidos)',
                    value: 'en-US',
                    selected: zd.lang == 'en-US'
                });
    
                var optionl2 = $('<option>', {
                    text: 'Español',
                    value: 'es-419',
                    selected: zd.lang == 'es-419'
                });
    
                guestLang.append( optionl1, optionl2 );

                // Select for Hotel
                var hotelSelect = $('<select>', {
                    name: 'hotel',
                    class: 'form-control mb-2 mr-sm-2'
                });
    
                var optionDef = $('<option>', {
                    value: '',
                    text: '-'
                }); 
    
                var optionDefA = $('<option>', {
                    value: '',
                    text: '-',
                }); 
                
                var option1 = $('<option>', {
                    text: 'ATELIER Playa Mujeres',
                    value: 'ATPM',
                    selected: zd.hotel == 'hotel_atpm'
                });
    
                var option2 = $('<option>', {
                    text: 'OLEO Cancun Playa',
                    value: 'OLCP',
                    selected: zd.hotel == 'hotel_olcp'
                });
    
                hotelSelect.append(optionDef, option1, option2);
    
                // Select for Roud - OneWay
                var travelSelect = $('<select>', {
                    name: 'travel',
                    class: 'form-control mb-2 mr-sm-2'
                });
                
                var optiont1 = $('<option>', {
                    text: 'Round-Trip',
                    value: 'transpo_round-trip',
                    selected: zd.travel == 'transpo_round-trip'
                });
    
                var optiont2 = $('<option>', {
                    text: 'Apto - Hotel',
                    value: 'transpo_a2h',
                    selected: zd.travel == 'transpo_a2h'
                });
    
                var optiont3 = $('<option>', {
                    text: 'Hotel - Apto',
                    value: 'transpo_h2a',
                    selected: zd.travel == 'transpo_h2a'
                });
    
    
                travelSelect.append( optiont1, optiont2, optiont3 );
    
                // Select for Type
                var typeSelect = $('<select>', {
                    name: 'type',
                    class: 'form-control mb-2 mr-sm-2'
                });
    
                var optionA = $('<option>', {
                    text: 'Con Pago',
                    value: '0',
                    selected: zd.pago == 'transpo_prepago'
                });
    
                var optionB = $('<option>', {
                    text: 'Cortesia',
                    value: '1',
                    selected: zd.pago == 'transpo_cortesia'
                });
    
                typeSelect.append(optionDefA, optionA, optionB);
    
                // Save button
                var saveButton = $('<button>', {
                    type: 'button',
                    id: "saveNewButton",
                    class: 'ml-auto btn btn-success mb-2',
                    html: '<i class="fa fa-save"></i>'
                });
    
                // Append inputs and button to the form
                form.append(guestNameInput, guestLang, hotelSelect, travelSelect, typeSelect, saveButton);
    
                // Append the form to the body or a specific container
                $('#result').html(`<div class="rsvError d-flex alert alert-primary">Capturar Nueva Reserva</div>`);
                $('#result').append(form);

                // Delegación de eventos
                document.getElementById('saveNewButton').addEventListener('click', function(event) {
                    startLoader();
                    console.log('click save');
                    var newForm = document.getElementById('newRegForm');
                    var inputs = newForm.elements;
                    var values = {
                        guest: inputs['guestName'].value,
                        hotel: inputs['hotel'].value,
                        type: inputs['type'].value,
                        travel: inputs['travel'].value,
                        idioma: inputs['idioma'].value,
                    };

                    setHotel( values['hotel'] );
                    setGuest( values['guest'] );
                    setField( 'ticket.customField:custom_field_28630449017748', values['travel'], "Tipo de Transpo" );
                    setTranspoPago( values['type'] == "1" ? "transpo_cortesia" : "transpo_prepago" );
                    setLang( zd.requesterId, values['idioma'] );
                    console.log("inputs: ", values);
                    startLoader(false);
                });
            });

        }

        function label( f, l ){
            return typeLabel = $('<label>', {
                text: l + ':', // Texto que quieres mostrar
                for: f, // Debe coincidir con el id del select
                class: 'form-label'
            });
        }

        
        
    });
</script>
<?= $this->endSection() ?>