<?php if(session('username')): ?>
    <p>
        <?= session('username') ?>
    </p>


<?php endif ?>