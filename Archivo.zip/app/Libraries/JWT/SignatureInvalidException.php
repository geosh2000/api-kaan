<?php

namespace App\Libraries\JWT;

class SignatureInvalidException extends \UnexpectedValueException
{
}
