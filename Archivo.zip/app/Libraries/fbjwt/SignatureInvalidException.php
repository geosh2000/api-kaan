<?php

namespace App\Libraries\fbjwt;

class SignatureInvalidException extends \UnexpectedValueException
{
}
